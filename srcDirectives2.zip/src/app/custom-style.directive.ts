import { Directive, ElementRef, Renderer2  } from '@angular/core';

@Directive({
  selector: '[appCustomStyle]',
  standalone: true
})
export class CustomStyleDirective {

  constructor(private obj : ElementRef , private renderer: Renderer2)
  { 
    obj.nativeElement.style.background = 'yellow';
    obj.nativeElement.style.fontWeight = 'bold';
   
  }    

}
