import { Component } from '@angular/core';

@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css'
})
export class DemoComponent 
{
    public message : String = "";
    public fun(caseType: string)
    {
      this.message = "Marvellous Infosystems";
      
      if (caseType === 'lower') 
      {
        this.message = this.message.toLowerCase();
      } 
      else if (caseType === 'upper')
      {
        this.message = this.message.toUpperCase();
      }
    }
    
}
