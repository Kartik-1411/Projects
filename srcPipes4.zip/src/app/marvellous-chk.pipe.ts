import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellousChk',
  standalone: true
})
export class MarvellousChkPipe implements PipeTransform 
{
  transform(value: number, param: string): string 
  {
    if (param === 'Prime') 
    {
      return this.isPrime(value) ? 'It is Prime number' : 'It is not Prime';
    } 
    else if (param === 'Perfect') 
    {
      return this.isPerfect(value) ? 'It is Perfect number' : 'It is not Perfect';
    } 
    else if (param === 'Even') 
    {
      return this.isEven(value) ? 'It is Even' : 'It is not Even';
    } 
    else if (param === 'Odd') 
    {
      return this.isOdd(value) ? 'It is Odd' : 'It is not Odd';
    } 
    else 
    {
      return 'Invalid parameter';
    }
  }

  public isPrime(num: number): boolean 
  {
    if (num <= 1) return false;
    for (let i = 1; i <= num; i++)
    {
      var iCnt : number = 0;
      if (num % i === 0) 
      {
        iCnt++;
      }
      if(iCnt > 2) 
      {
        return false;
      }
    }
    return true;
  }

  public isPerfect(num: number): boolean {
    var divisors: number[] = [];

    for (let i = 1; i < num; i++) 
    {
      if (num % i === 0) 
      {
        divisors.push(i);
      }
    }
    var sumOfDivisors = 0;
    for (let i = 0; i < divisors.length; i++) 
    {
      sumOfDivisors += divisors[i];
    }

    return sumOfDivisors === num;
  }

  public isEven(num: number): boolean {
    return num % 2 === 0;
  }

  public isOdd(num: number): boolean {
    return num % 2 !== 0;
  }
}