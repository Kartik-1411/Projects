import { Component } from '@angular/core';

@Component({
  selector: 'app-firstcomp',
  standalone: true,
  imports: [],
  templateUrl: './firstcomp.component.html',
  styleUrl: './firstcomp.component.css'
})
export class FirstcompComponent {

}
